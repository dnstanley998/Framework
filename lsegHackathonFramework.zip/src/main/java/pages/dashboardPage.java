package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import stepDefs.Base;

public class dashboardPage extends Base {

    @FindBy(xpath = "//span/h6")
    WebElement pageTitle;

    public String getTitle(){
        return pageTitle.getText();
    }
}
