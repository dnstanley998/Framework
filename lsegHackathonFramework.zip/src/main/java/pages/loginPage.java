package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import stepDefs.Base;

public class loginPage extends Base{

    @FindBy(xpath = "//input[@name='username']")
    WebElement userName;

    @FindBy(name = "password")
    WebElement password;

    @FindBy(xpath = "//button")
    WebElement loginBtn;


    public void typeUsername(String text){
        userName.sendKeys(text);
    }

    public void typePassword(String text){
        password.sendKeys(text);
    }

    public void clickLoginButton(){
        loginBtn.click();
    }

    public void login(String user,String pass){
        typeUsername(user);
        typePassword(pass);
        clickLoginButton();
    }
}
